# AI Motion Control Studio Personal — prototipe v0.1

PWA berbahasa Indonesia untuk penggunaan pribadi di Android. Termasuk:
- upload dan pratinjau gambar karakter;
- upload dan pratinjau video referensi;
- pilihan resolusi/durasi;
- pemeriksaan input awal;
- manifest dan service worker untuk instalasi PWA;
- scaffold API FastAPI.

## Status penting

Ini **prototipe UI**, belum aplikasi AI yang menghasilkan video. Tombol pemeriksaan hanya memvalidasi input di browser. Backend FastAPI sengaja mengembalikan `501` sampai mesin AI/GPU benar-benar dikonfigurasi. Tidak ada file yang diunggah oleh UI pada tahap ini.

## Cara mencoba di HP Android

PWA perlu disajikan lewat HTTPS atau localhost agar bisa dipasang dengan benar. Cara termudah adalah:
1. Ekstrak folder ini.
2. Unggah isi folder ke repositori GitHub milik sendiri.
3. Aktifkan GitHub Pages untuk repositori tersebut.
4. Buka URL Pages di Chrome Android.
5. Menu Chrome (⋮) → **Tambahkan ke layar utama** atau **Install app**.

Alternatif pengujian di komputer:
- Jalankan server statis dari folder ini, lalu buka URL HTTPS-nya di HP.
- Membuka `index.html` langsung dari file manager bisa menampilkan UI, tetapi kemampuan PWA/service worker mungkin tidak tersedia.

## API scaffold (opsional)

Dari folder `backend`:
```bash
python -m venv .venv
# aktifkan virtual environment
pip install -r requirements.txt
uvicorn main:app --host 127.0.0.1 --port 8000
```
Periksa `http://127.0.0.1:8000/api/health`.

API ini belum menghubungkan Wan Animate 2, SCAIL-2, ComfyUI, atau GPU cloud. Jangan mempublikasikan API tanpa autentikasi, pembatasan ukuran, HTTPS, penyimpanan sementara aman, dan penghapusan otomatis.

## Rencana integrasi AI

1. Pilih GPU cloud yang benar-benar gratis dan tersedia; kuota bisa berubah/habis.
2. Pastikan layanan secara eksplisit mendukung model dan mengizinkan integrasi.
3. Hubungkan worker ke workflow ComfyUI/model terpilih.
4. Tambahkan antrean, progres, batas durasi/resolusi, dan penghapusan input/output sementara.
5. Uji ekspor MP4 tanpa watermark tambahan dari aplikasi. Model atau layanan pihak ketiga bisa memiliki syarat tersendiri.

## Privasi

Pada prototipe UI, file diproses untuk pratinjau lokal browser dan tidak dikirim ke server. Saat backend AI diaktifkan, file akan perlu dikirim ke penyedia cloud; periksa kebijakan privasi dan jangan mengunggah materi sensitif tanpa memahami penyimpanannya.
