const $ = (id) => document.getElementById(id);
const characterInput = $("characterFile");
const motionInput = $("motionFile");
const characterPreview = $("characterPreview");
const motionPreview = $("motionPreview");
const statusBox = $("statusBox");

function setStatus(title, message, kind = "info") {
  statusBox.className = "notice";
  if (kind === "error") statusBox.style.borderColor = "#8d4848";
  else statusBox.style.borderColor = kind === "success" ? "#3d765e" : "#665532";
  statusBox.querySelector("strong").textContent = title;
  statusBox.querySelector("p").textContent = message;
}
function formatBytes(bytes) {
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(0) + " KB";
  return (bytes / (1024 * 1024)).toFixed(1) + " MB";
}
characterInput.addEventListener("change", () => {
  const file = characterInput.files?.[0];
  if (!file) return;
  if (!file.type.startsWith("image/")) {
    setStatus("Format gambar tidak sesuai", "Pilih file gambar JPG, PNG, atau WebP.", "error");
    characterInput.value = ""; return;
  }
  if (file.size > 20 * 1024 * 1024) {
    setStatus("Gambar terlalu besar", "Untuk prototipe, pilih gambar di bawah 20 MB.", "error");
    characterInput.value = ""; return;
  }
  characterPreview.src = URL.createObjectURL(file);
  characterPreview.classList.remove("hidden");
  $("characterName").textContent = `${file.name} · ${formatBytes(file.size)}`;
  setStatus("Gambar siap", "Gambar karakter sudah dipilih dan bisa ditinjau.", "success");
});
motionInput.addEventListener("change", () => {
  const file = motionInput.files?.[0];
  if (!file) return;
  if (!file.type.startsWith("video/")) {
    setStatus("Format video tidak sesuai", "Pilih video yang didukung browser, misalnya MP4.", "error");
    motionInput.value = ""; return;
  }
  if (file.size > 250 * 1024 * 1024) {
    setStatus("Video terlalu besar", "Untuk prototipe, pilih video di bawah 250 MB.", "error");
    motionInput.value = ""; return;
  }
  motionPreview.src = URL.createObjectURL(file);
  motionPreview.classList.remove("hidden");
  $("motionName").textContent = `${file.name} · ${formatBytes(file.size)}`;
  const meta = $("motionMeta");
  meta.classList.remove("hidden");
  motionPreview.onloadedmetadata = () => {
    const duration = Number.isFinite(motionPreview.duration) ? `${motionPreview.duration.toFixed(1)} detik` : "durasi tidak diketahui";
    meta.textContent = `Durasi: ${duration} · Resolusi sumber: ${motionPreview.videoWidth}×${motionPreview.videoHeight}`;
  };
  setStatus("Video referensi siap", "Video bisa dipratinjau. Pastikan gerakan dan tubuh terlihat jelas.", "success");
});
$("generateBtn").addEventListener("click", () => {
  const image = characterInput.files?.[0];
  const video = motionInput.files?.[0];
  if (!image || !video) {
    setStatus("Input belum lengkap", "Pilih gambar karakter dan video referensi sebelum melanjutkan.", "error");
    document.querySelector(!image ? "#characterZone" : "#motionZone").scrollIntoView({behavior:"smooth",block:"center"});
    return;
  }
  const resolution = $("resolution").value;
  const duration = $("duration").value;
  const identity = $("identity").checked;
  setStatus(
    "Input lolos pemeriksaan awal",
    `Gambar dan video terpilih. Target ${resolution}, durasi maksimal ${duration} detik, prioritas identitas ${identity ? "aktif" : "nonaktif"}. Backend GPU cloud belum disambungkan, sehingga generasi AI belum dijalankan. Tidak ada file yang diunggah.`,
    "success"
  );
  $("buttonHint").textContent = "Langkah berikutnya: sambungkan backend GPU cloud yang kompatibel.";
});
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {}));
}
