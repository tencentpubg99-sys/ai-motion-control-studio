"""
Starter backend only. No AI model is connected yet.
Run locally for API scaffolding; public deployment requires HTTPS, authentication,
file limits, cleanup, and a compatible GPU worker.
"""
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from uuid import uuid4

app = FastAPI(title="AI Motion Control Studio API", version="0.1.0")

# Restrict origins before any public deployment.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8000", "http://127.0.0.1:8000"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "ai_backend": "not_configured",
        "message": "API scaffold is alive; no GPU model is connected."
    }

@app.post("/api/generate")
async def generate(
    character: UploadFile = File(...),
    motion_video: UploadFile = File(...),
    resolution: str = Form("480p"),
    max_seconds: int = Form(5),
    prioritize_identity: bool = Form(True),
):
    allowed_resolutions = {"480p", "512p", "704p"}
    if resolution not in allowed_resolutions:
        raise HTTPException(400, "Resolusi tidak didukung.")
    if max_seconds not in {5, 10, 15}:
        raise HTTPException(400, "Durasi tidak didukung.")
    if not (character.content_type or "").startswith("image/"):
        raise HTTPException(400, "File karakter harus berupa gambar.")
    if not (motion_video.content_type or "").startswith("video/"):
        raise HTTPException(400, "File referensi harus berupa video.")

    # Intentionally does not pretend to generate video.
    # Add model-specific validation, secure temporary storage, queueing,
    # ComfyUI workflow submission, progress polling, and output download here.
    job_id = str(uuid4())
    raise HTTPException(
        status_code=501,
        detail={
            "job_id": job_id,
            "message": "GPU/model belum dikonfigurasi. Belum ada video yang dibuat."
        }
    )
